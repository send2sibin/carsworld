<?php 

include("config.php");
$suc="";
$alexists="";
$filename="";
$invalid="";
if(isset($_POST["btnaddcar"]))
{

if (($_FILES["file"]["type"] == "image/gif")
|| ($_FILES["file"]["type"] == "image/jpeg")
|| ($_FILES["file"]["type"] == "image/jpg")
&& ($_FILES["file"]["size"] < 200000000))
{
	
if ($_FILES["file"]["error"] > 0)
{
echo "Return Code: " . $_FILES["file"]["error"] . "<br />";
}
else
{
//echo "Upload: " . $_FILES["file"]["name"] . "<br />";
//echo "Type: " . $_FILES["file"]["type"] . "<br />";
//echo "Size: " . ($_FILES["file"]["size"] / 1024) . " Kb<br />";
//echo "Temp file: " . $_FILES["file"]["tmp_name"] . "<br />";
if (file_exists("cars/" . $_FILES["file"]["name"]))
{
$msg=$_FILES["file"]["name"] . " already exists. ";
$alexists=" <div class='alert alert-danger>
                             
                               $msg Choose different image and try again !!
                            </div>";

}
else
{
move_uploaded_file($_FILES["file"]["tmp_name"],
"cars/" . $_FILES["file"]["name"]);
$filename= $_FILES["file"]["name"];

$sql="INSERT INTO cars (cname,cspeed,cfuel,engined,power,torque,acceleration,carimg,mlgc,mlgh,mlgu,enginetyp,details)VALUES('$_POST[cname]','$_POST[speed]','$_POST[fuel]','$_POST[engined]','$_POST[power]','$_POST[torque]','$_POST[aclrtn]','$filename','$_POST[mlgc]','$_POST[mlgh]','$_POST[mlgu]','$_POST[engtype]','$_POST[dtls]')";
mysql_query($sql);
$suc=" <div class='alert alert-success'>
                               
                               Car details Successfully Added
                            </div>";
}
}
}
else
{
$invalid=" <div class='alert alert-warning'>
                               
                              Invalid file. Choose an image file..
                            </div>";
}



}


?>
<!DOCTYPE html>
<html>
<head>
<title>Carworld</title>
<!-- jQuery-->
<script src="../js/jquery.min.js"></script>
<!-- Custom Theme files -->
<!--theme-style-->
<link href="../css/style.css" rel="stylesheet" type="text/css" media="all" />	
<!--//theme-style-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Kappe Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--fonts-->
<link href='http://fonts.googleapis.com/css?family=Roboto:400,300,100,500,700,900' rel='stylesheet' type='text/css'>
<!--//fonts-->

</head>
<body>
	<div class="header">
		<div class="header-left header-work">
			<div class="logo">
				<a href="index.php"><img src="../images/logo.png" alt=""></a>
			</div>
			<div class="top-nav">
				<ul >
						<li ><a href="index.php" > Dashboard</a></li>
					<li  class="active"><a href="addcar.php" class="black" > Add Cars</a></li>	
					<li><a href="addcomfort.php" class="black1"> Add Comfort</a></li>
					<li><a href="addcapacity.php" class="black2" > Add Capacity</a></li>
					<li><a href="addperformance.php" class="black3" > Add Performance</a></li>
					<li><a href="addsafty.php" class="black4" > Add Safety</a></li>
					<li><a href="addothers.php" class="black4" > Add Others</a></li>
				</ul>
			</div>
			<ul class="social-in">
				<li><a href="#"><i> </i></a></li>
				<li><a href="#"><i class="gmail"> </i></a></li>
				<li><a href="#"><i class="twitter"> </i></a></li>
				<li><a href="#"><i class="pin"> </i></a></li>
				<li><a href="#"><i class="dribble"> </i></a></li>
				<li><a href="#"><i class="behance"> </i></a></li>
			</ul>
			<p class="footer-class">Copyright © 2016 Carworld by  <a href="#" target="_blank">Imili</a> </p>
		</div>
		<!---->
		<div class="header-top">
			<div class="logo-in">
				<a href="index.html"><img src="../images/logo.png" alt=""></a>
			</div>
			<div class="top-nav-in">
			<span class="menu"><img src="../images/menu.png" alt=""> </span>
				<ul >
					<li ><a href="ndex.php" >Dashboard</a></li>
					<li  class="active"><a href="addcar.php" class="black" > Add Cars</a></li>	
					<li><a href="addcomfort.php" class="black1"> Add Comfort</a></li>
					<li><a href="addcapacity.php" class="black2" > Add Capacity</a></li>
					<li><a href="addperformance.php" class="black3" > Add Performance</a></li>
					<li><a href="addsafty.php" class="black4" > Add Safety</a></li>
					<li><a href="addothers.php" class="black4" > Add Others</a></li>
				</ul>
				<script>
					$("span.menu").click(function(){
						$(".top-nav-in ul").slideToggle(500, function(){
						});
					});
			</script>

			</div>
			<div class="clear"> </div>
		</div>
			<!---->
		<div class="content">
			<div class="work">
				    <form role="form" action="addcar.php" method="post" onSubmit="return gal()" enctype="multipart/form-data">
				<div class="top-contact">
				 <?php  echo $suc; echo $alexists; echo $invalid; ?>
				<h3 class="bottom-h3">Add Car details</h3>
				<div class="grid-contact">
					<div class="your-top">
						
						<input type="text"  name="cname" placeholder="Car Name" required>								
						<div class="clear"> </div>
					</div>
					<div class="your-top">
						
						<input type="text" placeholder="Top-Speed(kmph)" name="speed" required>								
						<div class="clear"> </div>
					</div>
					<div class="your-top">
						
						<input type="text" placeholder="Fuel Type" name="fuel" required>								
						<div class="clear"> </div>
					</div>
					<div class="your-top">
						
						<input type="text" placeholder="Engine Displacement" name="engined" required>								
						<div class="clear"> </div>
					</div>
					<div class="your-top">
						
						<input type="text" placeholder="Power" name="power" required>								
						<div class="clear"> </div>
					</div>
					<div class="your-top">
						
						<input type="text" placeholder="Torque" name="torque" required>								
						<div class="clear"> </div>
					</div>
					<div class="your-top">
						
						<input type="text" placeholder="Acceleration" name="aclrtn" required>								
						<div class="clear"> </div>
					</div>
			<label>Select Car Image</label>
					<div class="your-top">
						
						<input type="file"  name="file" id="file" required>								
						<div class="clear"> </div>
					</div>
					
				</div>
				<div class="grid-contact-in">
						<div class="your-top">
						
						<input type="text" placeholder="Mileage City" name="mlgc" required>								
						<div class="clear"> </div>
					</div>
					<div class="your-top">
						
						<input type="text" placeholder="Mileage Highway" name="mlgh" required>								
						<div class="clear"> </div>
					</div>
					<div class="your-top">
						
						<input type="text" placeholder="Mileage Unit" name="mlgu" required>								
						<div class="clear"> </div>
					</div>
					<div class="your-top">
						
						<input type="text" placeholder="Engine Type" name="engtype" required>								
						<div class="clear"> </div>
					</div>
					<textarea cols="77" rows="5" placeholder="Introduction" name="dtls"></textarea>
					<input type="submit" name="btnaddcar" value="ADD CAR">
					<div class="your-top">
					
					</div>
				</div>
				<div class="clear"> </div>
			</div>
			</form>
				<div class="clear"> </div>
			</div>
		</div>
		<div class="clear"> </div>
				<p class="footer-class-in">Copyright © 2016 Carworld Template by  <a href="#" target="_blank">Imili</a> </p>

	</div>
</body>
</html>