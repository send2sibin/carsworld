<?php   
include("dbconfig.php");
include("config.php");
$cname=$_GET["cname"];
//select t1. *,t2. * from cars t1 inner join comfort t2 on t1.cname=t2.cname where t1.cname='$cname'
error_reporting( ~E_NOTICE );
	
	require_once 'dbconfig.php';
	$succ="";
	
	if(isset($_GET['cname']) && !empty($_GET['cname']))
	{
		$ids = $_GET['cname'];
		$stmt_edit = $DB_con->prepare('SELECT * FROM performance WHERE cname =:uid');
		$stmt_edit->execute(array(':uid'=>$ids));
		$edit_row = $stmt_edit->fetch(PDO::FETCH_ASSOC);
		extract($edit_row);
	}
	else
	{
		header("Location: addcar.php");
	}
	
	if(isset($_POST['btn_save_updates']))
	{
		$gb = $_POST['gb'];// user name
		$dt = $_POST['dt'];// user email
		$tr = $_POST['tr'];
		$noc = $_POST['noc'];
		$vpc = $_POST['vpc'];
		$ed = $_POST['ed'];
		$vc = $_POST['vc'];
		$fss = $_POST['fss'];
		$turboc = $_POST['turboc'];
		$superc = $_POST['superc'];
		
		
		
					

			$stmt = $DB_con->prepare('UPDATE performance 
									     SET gb=:ugb, 
										     dt=:udt, 
										     tr=:utr,
											  noc=:unoc,
											   vpc=:uvpc,
											    ed=:ued,
												 vc=:uvc,
												  fss=:ufss,
												   turboc=:uturboc,
												    superc=:usuperc	
								       WHERE cname=:uid');
			$stmt->bindParam(':ugb',$gb);
			$stmt->bindParam(':udt',$dt);
			$stmt->bindParam(':utr',$tr);
			$stmt->bindParam(':unoc',$noc);
			$stmt->bindParam(':uvpc',$vpc);
			$stmt->bindParam(':ued',$ed);
			$stmt->bindParam(':uvc',$vc);
			$stmt->bindParam(':ufss',$fss);
			$stmt->bindParam(':uturboc',$turboc);
			$stmt->bindParam(':usuperc',$superc);
			$stmt->bindParam(':uid',$ids);
				
			if($stmt->execute()){
				
				$succ="<div class='alert alert-success'>
                              
                               Successfully Updated ...
                            </div>"; ?>
               
                <?php
			}
			else{
				$errMSG ="<div class='alert alert-danger'>
                               
                               Sorry Data Could Not Updated !
                            </div>";
			}
		
		}
	
?>
<!DOCTYPE html>
<html>
<head>
<title></title>
<!-- jQuery-->
<script src="../js/jquery.min.js"></script>
<!-- Custom Theme files -->
<!--theme-style-->
<link href="../css/style.css" rel="stylesheet" type="text/css" media="all" />	
<!--//theme-style-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Kappe Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--fonts-->
<link href='http://fonts.googleapis.com/css?family=Roboto:400,300,100,500,700,900' rel='stylesheet' type='text/css'>
<!--//fonts-->
<style>
.em
{
color:#FF3300;
}
</style>
</head>
<body>
	<div class="header">
		<div class="header-left header-left3">
			<div class="logo">
				<a href="index.html"><img src="../images/logo.png" alt=""></a>
			</div>
			<div class="top-nav">
				<ul >
					<li><a href="index.php" >Dashboard</a></li>
					<li><a href="addcar.php" class="black" > Add Cars</a></li>	
					<li><a href="addcomfort.php" class="black1"> Add Comfort</a></li>
					<li><a href="addcapacity.php" class="black2" > Add Capacity</a></li>
					<li><a href="addperformance.php" class="black3" > Add Performance</a></li>
					<li><a href="addsafty.php" class="black4" > Add Safety</a></li>
					<li><a href="addothers.php" class="black4" > Add Others</a></li>
					<li><a href="carv.php" class="black5" > View Cars</a></li>
					<li><a href="delcar.php" class="black5" > Delete Cars</a></li>
				</ul>
			</div>
			<ul class="social-in">
				<li><a href="#"><i> </i></a></li>
				<li><a href="#"><i class="gmail"> </i></a></li>
				<li><a href="#"><i class="twitter"> </i></a></li>
				<li><a href="#"><i class="pin"> </i></a></li>
				<li><a href="#"><i class="dribble"> </i></a></li>
				<li><a href="#"><i class="behance"> </i></a></li>
			</ul>
			<p class="footer-class"> Template by  <a href="" target="_blank">Imili</a> </p>
		</div>
		<!---->
		<div class="header-top">
			<div class="logo-in">
				<a href="index.html"><img src="../images/logo.png" alt=""></a>
			</div>
			<div class="top-nav-in">
			<span class="menu"><img src="../images/menu.png" alt=""> </span>
				<ul >
					<li><a href="index.php" >Dashboard</a></li>
					<li><a href="addcar.php" class="black" > Add Cars</a></li>	
					<li><a href="addcomfort.php" class="black1"> Add Comfort</a></li>
					<li><a href="addcapacity.php" class="black2" > Add Capacity</a></li>
					<li><a href="addperformance.php" class="black3" > Add Performance</a></li>
					<li><a href="addsafty.php" class="black4" > Add Safety</a></li>
					<li><a href="addothers.php" class="black4" > Add Others</a></li>
					<li><a href="carv.php" class="black5" > View Cars</a></li>
					<li><a href="delcar.php" class="black5" > Delete Cars</a></li>
				</ul>
				<script>
					$("span.menu").click(function(){
						$(".top-nav-in ul").slideToggle(500, function(){
						});
					});
			</script>

			</div>
			<div class="clear"> </div>
		</div>
			<!---->
			
		<div class="content">
			<div class="single">
				<div class="single-top">
					<script src="../js/responsiveslides.min.js"></script>
					<script>
						$(function () {
						  $("#slider4").responsiveSlides({
							auto: true,
							speed: 500,
							namespace: "callbacks",
								pager: true,
						  });
						});
					</script>
					<div class="slider">
						<div class="callbacks_container">
						  <ul class="rslides" id="slider4">
							<li>
							<?php
	
 $result = mysql_query("select * from cars where cname='$cname'");
        while($row = mysql_fetch_array($result)) { 
            ?> 
							  <img src="cars/<?php echo $row['carimg']; ?>" alt="">
							  
							</li>
						
						  </ul>
					  </div>
					</div>
		
					<h2><?php echo $row['cname']; ?></h2>
					<p class="para"><?php echo $row['details']; ?> </p>
	
					<div class="info">
					<h3>Engine</h3>
					<a href="carse.php?cname=<?php echo $row['cname']; ?>"><p align="right">Edit</a>&nbsp;<a href="#">Delete</p></a>
						<ul class="likes">
							<li><span>Top Speed(kmph) : <em class="em"><?php echo $row['cspeed']; ?></em></span></li>
							<li><span>Fuel Type : <em class="em"><?php echo $row['cfuel']; ?></em></span></li>
							<li><span>Engine Displacement : <em class="em"><?php echo $row['engined']; ?></em></span></li>
							<li><span>Power : <em class="em"><?php echo $row['power']; ?></em></span></li>
							<li><span>Torque : <em class="em"><?php echo $row['torque']; ?></em></span></li>
							<li><span>Acceleration : <em class="em"><?php echo $row['acceleration']; ?></em></span></li>
							<li><span>Engine Type : <em class="em"><?php echo $row['enginetyp']; ?></em></span></li>
							<li><span>Mileage City : <em class="em"><?php echo $row['mlgc']; ?></em></span></li>
							<li><span>Mileage Highway : <em class="em"><?php echo $row['mlgh']; ?></em></span></li>
							<li><span>Mileage Unit : <em class="em"><?php echo $row['mlgu']; ?></span></em></li>
				
						</ul>
					</div>
						<?php } ?>
										<?php
	
 $result = mysql_query("select * from comfort where cname='$cname'");
        while($row = mysql_fetch_array($result)) { 
            ?> 
					
					<div class="info">
					<h3>Comfort</h3>
						<a href="comforte.php?cname=<?php echo $row['cname']; ?>"><p align="right">Edit</a>&nbsp;<a href="#">Delete</p></a>
						<ul class="likes">
							<li><span>Transmission Type : <em class="em"><?php echo $row['trantyp']; ?></em></span></li>
							<li><span>Front Suspension : <em class="em"><?php echo $row['fs']; ?></em></span></li>
							<li><span>Rear Suspension : <em class="em"><?php echo $row['rs']; ?></em></span></li>
							<li><span>Shock Absorbers Type : <em class="em"><?php echo $row['sat']; ?></em></span></li>
							<li><span>Accessory Power Outlet : <em class="em"><?php echo $row['apo']; ?></em></span></li>
							<li><span>Cup Holders-Front : <em class="em"><?php echo $row['chf']; ?></em></span></li>
							<li><span>Low Fuel Warning Light : <em class="em"><?php echo $row['lfwl']; ?></em></span></li>
							<li><span>Power Steering : <em class="em"><?php echo $row['ps']; ?></em></span></li>
							<li><span>Rear Seat Headrest : <em class="em"><?php echo $row['rsh']; ?></em></span></li>
							<li><span>Remote Fuel Lid Opener : <em class="em"><?php echo $row['rflo']; ?></em></span></li>
							<li><span>Remote Trunk Opener : <em class="em"><?php echo $row['rto']; ?></em></span></li>
							<li><span>Bottle Holder : <em class="em"><?php echo $row['bh']; ?></em></span></li>
							<li><span>Foldable Rear Seat : <em class="em"><?php echo $row['frs']; ?></em></span></li>
							<li><span>Air Conditioner : <em class="em"><?php echo $row['ac']; ?></em></span></li>
								<li><span>Fabric Upholstery : <em class="em"><?php echo $row['fu']; ?></em></span></li>
									<li><span>Adjustable Seats : <em class="em"><?php echo $row['ast']; ?></em></span></li>
						
					
						</ul>
					</div>
					<?php } ?>
					
										<?php
	
 $result = mysql_query("select * from safty where cname='$cname'");
        while($row = mysql_fetch_array($result)) { 
            ?>
					<div class="info">
					<h3>Safty</h3>
						<a href="saftye.php?cname=<?php echo $row['cname']; ?>"><p align="right">Edit</a>&nbsp;<a href="#">Delete</p></a>
						<ul class="likes">
							<li><span>Front Brake Type : <em class="em"><?php echo $row['fbt']; ?></em></span></li>
							<li><span>Rear Brake Type : <em class="em"><?php echo $row['rbt']; ?></em></span></li>
							<li><span>Parking Sensors : <em class="em"><?php echo $row['ps']; ?></em></span></li>
							<li><span>Centrally Mounted Fuel Tank : <em class="em"><?php echo $row['cmft']; ?></em></span></li>
							<li><span>Child Safety Locks : <em class="em"><?php echo $row['csl']; ?></em></span></li>
							<li><span>Day & Night Rear View Mirror : <em class="em"><?php echo $row['rvm']; ?></em></span></li>
							<li><span>Engine Immobilizer : <em class="em"><?php echo $row['ei']; ?></em></span></li>
							<li><span>Front Impact Beams : <em class="em"><?php echo $row['fib']; ?></em></span></li>
							<li><span>Rear Seat Belts : <em class="em"><?php echo $row['rsb']; ?></em></span></li>
							<li><span>Seat Belt Warning : <em class="em"><?php echo $row['sbw']; ?></em></span></li>
							<li><span>Side Impact Beams : <em class="em"><?php echo $row['sib']; ?></em></span></li>
							
						
				
						</ul>
					</div>
						<?php } ?>
									
				</div>
				<div class="single-in">
																		<?php
	
 $result = mysql_query("select * from capacity where cname='$cname'");
        while($row = mysql_fetch_array($result)) { 
            ?>
					<div class="info">
					<h3>Capacity</h3>
						<a href="capacitye.php?cname=<?php echo $row['cname']; ?>"><p align="right">Edit</a>&nbsp;<a href="#">Delete</p></a>
						<ul class="likes">
							<li><span>Length : <em class="em"><?php echo $row['l']; ?></em></span></li>
							<li><span>Width : <em class="em"><?php echo $row['w']; ?></em></span></li>
							<li><span>Height : <em class="em"><?php echo $row['h']; ?></em></span></li>
							<li><span>Ground Clearance : <em class="em"><?php echo $row['gc']; ?></em></span></li>
							<li><span>Wheel Base : <em class="em"><?php echo $row['wb']; ?></em></span></li>
							<li><span>Front Tread : <em class="em"><?php echo $row['ft']; ?></em></span></li>
							<li><span>Rear Tread : <em class="em"><?php echo $row['rt']; ?></em></span></li>
							<li><span>Seating Capacity : <em class="em"><?php echo $row['sc']; ?></em></span></li>
							<li><span>Tyre Size : <em class="em"><?php echo $row['ts']; ?></em></span></li>
							<li><span>Tyre Type : <em class="em"><?php echo $row['tt']; ?></em></span></li>
							<li><span>Wheel Size : <em class="em"><?php echo $row['ws']; ?></em></span></li>
							<li><span>No of Doors : <em class="em"><?php echo $row['nod']; ?></em></span></li>
							<li><span>Cargo Volume : <em class="em"><?php echo $row['cv']; ?></em></span></li>
							<li><span>Fuel Tank Capacity (litres) : <em class="em"><?php echo $row['ftc']; ?></em></span></li>
							
						
					
						</ul>
					</div>
					<?php } ?>
					<?php
	
 $result = mysql_query("select * from performance where cname='$cname'");
        while($row = mysql_fetch_array($result)) { 
            ?>
					 <form method="post" enctype="multipart/form-data" class="form-horizontal">
					<div class="info">
					<h3>Performance</h3>
						
						<ul class="likes">
							<li><span>Gear box : <em class="em"><input type="text" value="<?php echo $gb; ?>" name="gb" ></em></span></li>
							<li><span>Drive Type : <em class="em"><input type="text" value="<?php echo $dt; ?>" name="dt" ></em></span></li>
							<li><span>Turning Radius : <em class="em"><input type="text" value="<?php echo $tr; ?>" name="tr" ></em></span></li>
							<li><span>No of Cylinders : <em class="em"><input type="text" value="<?php echo $noc; ?>" name="noc" ></em></span></li>
							<li><span>Valves Per Cylinder : <em class="em"><input type="text" value="<?php echo $vpc; ?>" name="vpc" ></em></span></li>
							<li><span>Engine Description : <em class="em"><input type="text" value="<?php echo $ed; ?>" name="ed" ></em></span></li>
							<li><span>Valve Configuration : <em class="em"><input type="text" value="<?php echo $vc; ?>" name="vc" ></em></span></li>
							<li><span>Fuel Supply System : <em class="em"><input type="text" value="<?php echo $fss; ?>" name="fss" ></em></span></li>
							<li><span>Turbo Charger : <em class="em"><input type="text" value="<?php echo $turboc; ?>" name="turboc" ></em></span></li>
							<li><span>Super Charger : <em class="em"><input type="text" value="<?php echo $superc; ?>" name="superc" ></em></span></li>
					
						</ul>
						<input type="submit" name="btn_save_updates" value="Update">&nbsp;<a href="car_single.php?cname=<?php echo $row['cname']; ?>"><input type="button" value="Back"></a>
						<?php echo $succ; echo $errMSG; ?>
					</div></form>
					<?php } ?>
					
					<?php
	
 $result = mysql_query("select * from others where cname='$cname'");
        while($row = mysql_fetch_array($result)) { 
            ?>
					<div class="info">
					<h3>Others</h3>
						<a href="otherse.php?cname=<?php echo $row['cname']; ?>"><p align="right">Edit</a>&nbsp;<a href="#">Delete</p></a>
						<ul class="likes">
							<li><span>Steering Type : <em class="em"><?php echo $row['st']; ?></em></span></li>
							<li><span>Emission Norm Compliance : <em class="em"><?php echo $row['enc']; ?></em></span></li>
							<li><span>Power Windows Front : <em class="em"><?php echo $row['pwf']; ?></em></span></li>
							<li><span>Adjustable Headlights : <em class="em"><?php echo $row['ah']; ?></em></span></li>
							<li><span>Manually Adjustable Exterior Rear View Mirror : <em class="em"><?php echo $row['ervm']; ?></em></span></li>
							<li><span>Tinted Glass : <em class="em"><?php echo $row['tg']; ?></em></span></li>
							<li><span>Rear Spoiler : <em class="em"><?php echo $row['rs']; ?></em></span></li>
							<li><span>Chrome Grille : <em class="em"><?php echo $row['cg']; ?></em></span></li>
							<li><span>Heater : <em class="em"><?php echo $row['htr']; ?></em></span></li>
							<li><span>Digital Odometer : <em class="em"><?php echo $row['do']; ?></em></span></li>
							<li><span>Electronic Multi Tripmeter : <em class="em"><?php echo $row['emt']; ?></em></span></li>
							<li><span>Electric Adjustable Seats : <em class="em"><?php echo $row['eas']; ?></em></span></li>
							<li><span>Anti Theft Device : <em class="em"><?php echo $row['atd']; ?></em></span></li>
						
							
						
				
						</ul>
					</div>
			
					<?php } ?>	
				
				</div>
				<div class="clear"> </div>
			</div>
		</div>
		<div class="clear"> </div>
				<p class="footer-class-in">Copyright © 2016 Carworld Template by  <a href="" target="_blank">Imili</a> </p>

	</div>
</body>
</html>