<?php 

include("config.php");

$suc="";
$fail="";
if(isset($_POST["btnaddothers"]))
{
$cname=$_POST['cname'];
$st=$_POST['st'];
$enc=$_POST['enc'];
$pwf=$_POST['pwf'];
$ah=$_POST['ah'];
$ervm=$_POST['ervm'];
$tg=$_POST['tg'];
$rs=$_POST['rs'];
$cg=$_POST['cg'];
$htr=$_POST['htr'];
$do=$_POST['do'];
$emt=$_POST['emt'];
$eas=$_POST['eas'];
$atd=$_POST['atd'];



if(!empty($cname) &&  !empty($st) && !empty($enc) && !empty($pwf) && !empty($ah) && !empty($ervm) && !empty($tg) && !empty($rs) && !empty($cg) && !empty($htr) && !empty($do) && !empty($emt) && !empty($eas) && !empty($atd))
{

$query="insert into others values('$cname','$st','$enc','$pwf','$ah','$ervm','$tg','$rs','$cg','$htr','$do','$emt','$eas','$atd')";
mysql_query($query);
$suc=" <div class='alert alert-success'>
                               
                               Other details Successfully Added
                            </div>";
}
else
	$fail=" <div class='alert alert-warning'>
                               
                               Some field is empty. The field is not available write 'NIL'
                            </div>";
}

?>
<!DOCTYPE html>
<html>
<head>
<title>Carworld</title>
<!-- jQuery-->
<script src="../js/jquery.min.js"></script>
<!-- Custom Theme files -->
<!--theme-style-->
<link href="../css/style.css" rel="stylesheet" type="text/css" media="all" />	
<!--//theme-style-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Kappe Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--fonts-->
<link href='http://fonts.googleapis.com/css?family=Roboto:400,300,100,500,700,900' rel='stylesheet' type='text/css'>
<!--//fonts-->

</head>
<body>
	<div class="header">
		<div class="header-left header-work">
			<div class="logo">
				<a href="index.html"><img src="../images/logo.png" alt=""></a>
			</div>
			<div class="top-nav">
				<ul >
						<li><a href="index.php" >Dashboard</a></li>
					<li><a href="addcar.php" class="black" > Add Cars</a></li>	
					<li><a href="addcomfort.php" class="black1"> Add Comfort</a></li>
					<li><a href="addcapacity.php" class="black2" > Add Capacity</a></li>
					<li><a href="addperformance.php" class="black3" > Add Performance</a></li>
					<li><a href="addsafty.php" class="black4" > Add Safety</a></li>
					<li  class="active"><a href="addothers.php" class="black4" > Add Others</a></li>
				</ul>
			</div>
			<ul class="social-in">
				<li><a href="#"><i> </i></a></li>
				<li><a href="#"><i class="gmail"> </i></a></li>
				<li><a href="#"><i class="twitter"> </i></a></li>
				<li><a href="#"><i class="pin"> </i></a></li>
				<li><a href="#"><i class="dribble"> </i></a></li>
				<li><a href="#"><i class="behance"> </i></a></li>
			</ul>
			<p class="footer-class">Copyright © 2016 Carworld by  <a href="#" target="_blank">Imili</a> </p>
		</div>
		<!---->
		<div class="header-top">
			<div class="logo-in">
				<a href="index.php"><img src="../images/logo.png" alt=""></a>
			</div>
			<div class="top-nav-in">
			<span class="menu"><img src="../images/menu.png" alt=""> </span>
				<ul >
					<li><a href="index.php" >Dashboard</a></li>
					<li><a href="addcar.php" class="black" > Add Cars</a></li>	
					<li><a href="addcomfort.php" class="black1"> Add Comfort</a></li>
					<li><a href="addcapacity.php" class="black2" > Add Capacity</a></li>
					<li><a href="addperformance.php" class="black3" > Add Performance</a></li>
					<li><a href="addsafty.php" class="black4" > Add Safety</a></li>
					<li  class="active"><a href="addothers.php" class="black4" > Add Others</a></li>
				</ul>
				<script>
					$("span.menu").click(function(){
						$(".top-nav-in ul").slideToggle(500, function(){
						});
					});
			</script>

			</div>
			<div class="clear"> </div>
		</div>
			<!---->
		<div class="content">
			<div class="work">
				    <form role="form" action="addothers.php" method="post">
				<div class="top-contact">
			<?php echo $suc; echo $fail; ?>
				<h3 class="bottom-h3">Add Others</h3>
				<div class="grid-contact">
				<div class="your-top">
					
						<select name="cname">
<option value="">--- Select Car for add other details ---</option>
 <?php
	
 $result = mysql_query("SELECT * from cars order by carid asc");
        while($row = mysql_fetch_array($result)) { 
            ?>     
<option value="<?php echo $row['cname']; ?>"><?php echo $row['cname']; ?></option>
		<?php } ?>
</select>						
						<div class="clear"> </div>
					</div>
					<div class="your-top">
						
						<input type="text"  name="st" placeholder="Steering Type">								
						<div class="clear"> </div>
					</div>
					<div class="your-top">
						
						<input type="text" placeholder="Emission Norm Compliance" name="enc" >								
						<div class="clear"> </div>
					</div>
					<div class="your-top">
						
						<input type="text" placeholder="Power Windows Front" name="pwf" >								
						<div class="clear"> </div>
					</div>
					<div class="your-top">
						
						<input type="text" placeholder="Adjustable Headlights" name="ah" >								
						<div class="clear"> </div>
					</div>
					<div class="your-top">
						
						<input type="text" placeholder="Manually Adjustable Exterior Rear View Mirror" name="ervm" >								
						<div class="clear"> </div>
					</div>
					<div class="your-top">
						
						<input type="text" placeholder="Tinted Glass" name="tg">								
						<div class="clear"> </div>
					</div>
						<div class="your-top">
						
						<input type="text" placeholder="Rear Spoiler" name="rs">								
						<div class="clear"> </div>
					</div>
					
				</div>
				<div class="grid-contact-in">
			
			<div class="your-top">
						
						<input type="text" placeholder="Chrome Grille" name="cg">								
						<div class="clear"> </div>
					</div>
				
							<div class="your-top">
						
						<input type="text" placeholder="Heater" name="htr">								
						<div class="clear"> </div>
					</div>
					<div class="your-top">
						
						<input type="text" placeholder="Digital Odometer" name="do">								
						<div class="clear"> </div>
					</div>
						<div class="your-top">
						
						<input type="text" placeholder="Electronic Multi Tripmeter" name="emt">								
						<div class="clear"> </div>
					</div>
						<div class="your-top">
						
						<input type="text" placeholder="Electric Adjustable Seats" name="eas" >								
						<div class="clear"> </div>
					</div>
					<div class="your-top">
						
						<input type="text" placeholder="Anti Theft Device" name="atd" >								
						<div class="clear"> </div>
					</div>
				
				
				
					<input type="submit" name="btnaddothers" value="ADD OTHERS">
					
				</div>
				<div class="clear"> </div>
			</div>
			</form>
				<div class="clear"> </div>
			</div>
		</div>
		<div class="clear"> </div>
				<p class="footer-class-in">Copyright © 2016 Carworld Template by  <a href="#" target="_blank">Imili</a> </p>

	</div>
</body>
</html>