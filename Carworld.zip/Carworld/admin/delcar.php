<?php 

include("config.php");
include("dbconfig.php");
$suc="";
$fail="";
if(isset($_POST["delcar"]))
{
$cname=$_POST['cname'];




if(!empty($cname))
{

$query="delete t1.* ,t2.*,t3.*,t4.*,t5.*,t6.* from cars t1 inner join capacity t2 on t1.cname=t2.cname inner join performance t3 on t1.cname=t3.cname inner join safty t4 on t1.cname=t4.cname inner join comfort t5 on t1.cname=t5.cname inner join others t6 on t1.cname=t6.cname where t1.cname='$cname'";
mysql_query($query);

$suc=" <div class='alert alert-success'>
                               
                               $cname Successfully Deleted
                            </div>";
}
else
	$fail=" <div class='alert alert-warning'>
                               
                               Select any car and continue
                            </div>";
}

?>
<!DOCTYPE html>
<html>
<head>
<title>Carworld</title>
<!-- jQuery-->
<script src="../js/jquery.min.js"></script>
<!-- Custom Theme files -->
<!--theme-style-->
<link href="../css/style.css" rel="stylesheet" type="text/css" media="all" />	
<!--//theme-style-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Kappe Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--fonts-->
<link href='http://fonts.googleapis.com/css?family=Roboto:400,300,100,500,700,900' rel='stylesheet' type='text/css'>
<!--//fonts-->

</head>
<body>
	<div class="header">
		<div class="header-left header-work">
			<div class="logo">
				<a href="index.php"><img src="../images/logo.png" alt=""></a>
			</div>
			<div class="top-nav">
				<ul >
					<li><a href="index.php" >Dashboard</a></li>
					<li><a href="addcar.php" class="black" > Add Cars</a></li>	
					<li><a href="addcomfort.php" class="black1"> Add Comfort</a></li>
					<li><a href="addcapacity.php" class="black2" > Add Capacity</a></li>
					<li><a href="addperformance.php" class="black3" > Add Performance</a></li>
					<li><a href="addsafty.php" class="black4" > Add Safety</a></li>
					<li><a href="addothers.php" class="black4" > Add Others</a></li>
					<li><a href="carv.php" class="black5" > View Cars</a></li>
					<li  class="active" ><a href="delcar.php" class="black5" > Delete Cars</a></li>
				</ul>
			</div>
			<ul class="social-in">
				<li><a href="#"><i> </i></a></li>
				<li><a href="#"><i class="gmail"> </i></a></li>
				<li><a href="#"><i class="twitter"> </i></a></li>
				<li><a href="#"><i class="pin"> </i></a></li>
				<li><a href="#"><i class="dribble"> </i></a></li>
				<li><a href="#"><i class="behance"> </i></a></li>
			</ul>
			<p class="footer-class">Copyright © 2016 Carworld by  <a href="#" target="_blank">Imili</a> </p>
		</div>
		<!---->
		<div class="header-top">
			<div class="logo-in">
				<a href="index.php"><img src="../images/logo.png" alt=""></a>
			</div>
			<div class="top-nav-in">
			<span class="menu"><img src="../images/menu.png" alt=""> </span>
				<ul >
			<li><a href="index.php" >Dashboard</a></li>
					<li><a href="addcar.php" class="black" > Add Cars</a></li>	
					<li><a href="addcomfort.php" class="black1"> Add Comfort</a></li>
					<li><a href="addcapacity.php" class="black2" > Add Capacity</a></li>
					<li><a href="addperformance.php" class="black3" > Add Performance</a></li>
					<li><a href="addsafty.php" class="black4" > Add Safety</a></li>
					<li><a href="addothers.php" class="black4" > Add Others</a></li>
					<li><a href="carv.php" class="black5" > View Cars</a></li>
					<li  class="active" ><a href="delcar.php" class="black5" > Delete Cars</a></li>
				</ul>
				<script>
					$("span.menu").click(function(){
						$(".top-nav-in ul").slideToggle(500, function(){
						});
					});
			</script>

			</div>
			<div class="clear"> </div>
		</div>
			<!---->
		<div class="content">
			<div class="work">
				    <form role="form" action="delcar.php" method="post">
				<div class="top-contact">
			<?php echo $suc; echo $fail; ?>
				<h3 class="bottom-h3">Delete Car</h3>
				<div class="grid-contact-in">
				<div class="your-top">
					
						<select name="cname" style="width:480px;">
<option value="">--- Select Car for Delete ---</option>
 <?php
	
 $result = mysql_query("SELECT * from cars order by carid asc");
        while($row = mysql_fetch_array($result)) { 
            ?>     
<option value="<?php echo $row['cname']; ?>"><?php echo $row['cname']; ?></option>
		<?php } ?>
</select>						
						<div class="clear"> </div>
						<br>
						<input type="submit" name="delcar" value="DELETE">
					</div>
					
						
				</div>
		
				<div class="clear"> </div>
			</div>
			</form>
				<div class="clear"> </div>
			</div>
		</div>
		<div class="clear"> </div>
				<p class="footer-class-in">Copyright © 2016 Carworld Template by  <a href="#" target="_blank">Imili</a> </p>

	</div>
</body>
</html>