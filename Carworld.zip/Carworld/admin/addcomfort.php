<?php 

include("config.php");

$suc="";
$fail="";
if(isset($_POST["btnaddcomfort"]))
{
$cname=$_POST['cname'];
$trantyp=$_POST['trtyp'];
$fs=$_POST['fs'];
$rs=$_POST['rs'];
$sat=$_POST['sat'];
$apo=$_POST['apo'];
$chf=$_POST['chf'];
$lfwl=$_POST['lfwl'];
$ps=$_POST['ps'];
$rsh=$_POST['rsh'];
$rflo=$_POST['rflo'];
$rto=$_POST['rto'];
$bh=$_POST['bh'];
$frs=$_POST['frs'];
$ac=$_POST['ac'];
$fu=$_POST['fu'];
$ast=$_POST['ast'];

if(!empty($cname) && !empty($trantyp) && !empty($fs) && !empty($rs) && !empty($sat) && !empty($apo) && !empty($chf) && !empty($lfwl) && !empty($ps) && !empty($rsh) && !empty($rflo) && !empty($rto) && !empty($bh) && !empty($frs) && !empty($ac) && !empty($fu) && !empty($ast))
{

$query="insert into comfort values('$cname','$trantyp','$fs','$rs','$sat','$apo','$chf','$lfwl','$ps','$rsh','$rflo','$rto','$bh','$frs','$ac','$fu','$ast')";
mysql_query($query);
$suc=" <div class='alert alert-success'>
                               
                               Comfort details Successfully Added
                            </div>";
}
else
	$fail=" <div class='alert alert-warning'>
                               
                               Some field is empty. The field is not available write 'NIL'
                            </div>";
}

?>
<!DOCTYPE html>
<html>
<head>
<title>Carworld</title>
<!-- jQuery-->
<script src="../js/jquery.min.js"></script>
<!-- Custom Theme files -->
<!--theme-style-->
<link href="../css/style.css" rel="stylesheet" type="text/css" media="all" />	
<!--//theme-style-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Kappe Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--fonts-->
<link href='http://fonts.googleapis.com/css?family=Roboto:400,300,100,500,700,900' rel='stylesheet' type='text/css'>
<!--//fonts-->

</head>
<body>
	<div class="header">
		<div class="header-left header-work">
			<div class="logo">
				<a href="index.html"><img src="../images/logo.png" alt=""></a>
			</div>
			<div class="top-nav">
				<ul >
					<li><a href="index.php" >Dashboard</a></li>
					<li><a href="addcar.php" class="black" > Add Cars</a></li>	
					<li class="active"><a href="addcomfort.php" class="black1"> Add Comfort</a></li>
					<li><a href="addcapacity.php" class="black2" > Add Capacity</a></li>
					<li><a href="addperformance.php" class="black3" > Add Performance</a></li>
					<li><a href="addsafty.php" class="black4" > Add Safety</a></li>
					<li><a href="addothers.php" class="black4" > Add Others</a></li>
				</ul>
			</div>
			<ul class="social-in">
				<li><a href="#"><i> </i></a></li>
				<li><a href="#"><i class="gmail"> </i></a></li>
				<li><a href="#"><i class="twitter"> </i></a></li>
				<li><a href="#"><i class="pin"> </i></a></li>
				<li><a href="#"><i class="dribble"> </i></a></li>
				<li><a href="#"><i class="behance"> </i></a></li>
			</ul>
			<p class="footer-class">Copyright © 2016 Carworld by  <a href="#" target="_blank">Imili</a> </p>
		</div>
		<!---->
		<div class="header-top">
			<div class="logo-in">
				<a href="index.php"><img src="../images/logo.png" alt=""></a>
			</div>
			<div class="top-nav-in">
			<span class="menu"><img src="../images/menu.png" alt=""> </span>
				<ul >
					<li><a href="index.php" >Dashboard</a></li>
					<li><a href="addcar.php" class="black" > Add Cars</a></li>	
					<li class="active"><a href="addcomfort.php" class="black1"> Add Comfort</a></li>
					<li><a href="addcapacity.php" class="black2" > Add Capacity</a></li>
					<li><a href="addperformance.php" class="black3" > Add Performance</a></li>
					<li><a href="addsafty.php" class="black4" > Add Safety</a></li>
					<li><a href="addothers.php" class="black4" > Add Others</a></li>
				</ul>
				<script>
					$("span.menu").click(function(){
						$(".top-nav-in ul").slideToggle(500, function(){
						});
					});
			</script>

			</div>
			<div class="clear"> </div>
		</div>
			<!---->
		<div class="content">
			<div class="work">
				    <form role="form" action="addcomfort.php" method="post">
				<div class="top-contact">
			<?php echo $suc; echo $fail; ?>
				<h3 class="bottom-h3">Add Comfort</h3>
				<div class="grid-contact">
				<div class="your-top">
					
						<select name="cname">
<option value="">--- Select Car for add comfort details ---</option>
 <?php
	
 $result = mysql_query("SELECT * from cars order by carid asc");
        while($row = mysql_fetch_array($result)) { 
            ?>     
<option value="<?php echo $row['cname']; ?>"><?php echo $row['cname']; ?></option>
		<?php } ?>
</select>						
						<div class="clear"> </div>
					</div>
					<div class="your-top">
						
						<input type="text"  name="trtyp" placeholder="Transmission Type" required>								
						<div class="clear"> </div>
					</div>
					<div class="your-top">
						
						<input type="text" placeholder="Front Suspension" name="fs" required>								
						<div class="clear"> </div>
					</div>
					<div class="your-top">
						
						<input type="text" placeholder="Rear Suspension" name="rs" required>								
						<div class="clear"> </div>
					</div>
					<div class="your-top">
						
						<input type="text" placeholder="Shock Absorbers Type" name="sat" required>								
						<div class="clear"> </div>
					</div>
					<div class="your-top">
						
						<input type="text" placeholder="Accessory Power Outlet" name="apo" required>								
						<div class="clear"> </div>
					</div>
					<div class="your-top">
						
						<input type="text" placeholder="Cup Holders-Front" name="chf" required>								
						<div class="clear"> </div>
					</div>
					<div class="your-top">
						
						<input type="text" placeholder="Low Fuel Warning Light" name="lfwl" required>								
						<div class="clear"> </div>
					</div>
			<div class="your-top">
						
						<input type="text" placeholder="Power Steering" name="ps" required>								
						<div class="clear"> </div>
					</div>
				
							<div class="your-top">
						
						<input type="text" placeholder="Rear Seat Headrest" name="rsh" required>								
						<div class="clear"> </div>
					</div>
				</div>
				<div class="grid-contact-in">
				
						<div class="your-top">
						
						<input type="text" placeholder="Remote Fuel Lid Opener" name="rflo" required>								
						<div class="clear"> </div>
					</div>
						<div class="your-top">
						
						<input type="text" placeholder="Remote Trunk Opener" name="rto" required>								
						<div class="clear"> </div>
					</div>
					<div class="your-top">
						
						<input type="text" placeholder="Bottle Holder" name="bh" required>								
						<div class="clear"> </div>
					</div>
					<div class="your-top">
						
						<input type="text" placeholder="Foldable Rear Seat" name="frs" required>								
						<div class="clear"> </div>
					</div>
					<div class="your-top">
						
						<input type="text" placeholder="Air Conditioner" name="ac" required>								
						<div class="clear"> </div>
					</div>
					<div class="your-top">
						
						<input type="text" placeholder="Fabric Upholstery" name="fu" required>								
						<div class="clear"> </div>
					</div>
					<div class="your-top">
						
						<input type="text" placeholder="Adjustable Seats" name="ast" required>								
						<div class="clear"> </div>
					</div>
				
					<input type="submit" name="btnaddcomfort" value="ADD COMFORT">
					<div class="your-top">
					
					</div>
				</div>
				<div class="clear"> </div>
			</div>
			</form>
				<div class="clear"> </div>
			</div>
		</div>
		<div class="clear"> </div>
				<p class="footer-class-in">Copyright © 2016 Carworld Template by  <a href="#" target="_blank">Imili</a> </p>

	</div>
</body>
</html>