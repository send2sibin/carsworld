<?php

$con=mysql_connect('localhost','root','')or die("could not connect to server");
$db=mysql_select_db("carworld",$con)or die("could not connect to database");
?>
