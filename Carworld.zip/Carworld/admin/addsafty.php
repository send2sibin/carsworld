<?php 

include("config.php");

$suc="";
$fail="";
if(isset($_POST["btnaddsafty"]))
{
$cname=$_POST['cname'];
$fbt=$_POST['fbt'];
$rbt=$_POST['rbt'];
$ps=$_POST['ps'];
$cmft=$_POST['cmft'];
$csl=$_POST['csl'];
$rvm=$_POST['rvm'];
$ei=$_POST['ei'];
$fib=$_POST['fib'];
$rsb=$_POST['rsb'];
$sbw=$_POST['sbw'];
$sib=$_POST['sib'];


if(!empty($cname) &&  !empty($fbt) && !empty($rbt) && !empty($ps) && !empty($cmft) && !empty($csl) && !empty($rvm) && !empty($ei) && !empty($fib) && !empty($rsb) && !empty($sbw) && !empty($sib))
{

$query="insert into safty values('$cname','$fbt','$rbt','$ps','$cmft','$csl','$rvm','$ei','$fib','$rsb','$sbw','$sib')";
mysql_query($query);
$suc=" <div class='alert alert-success'>
                               
                               Safty details Successfully Added
                            </div>";
}
else
	$fail=" <div class='alert alert-warning'>
                               
                               Some field is empty. The field is not available write 'NIL'
                            </div>";
}

?>
<!DOCTYPE html>
<html>
<head>
<title>Carworld</title>
<!-- jQuery-->
<script src="../js/jquery.min.js"></script>
<!-- Custom Theme files -->
<!--theme-style-->
<link href="../css/style.css" rel="stylesheet" type="text/css" media="all" />	
<!--//theme-style-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Kappe Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--fonts-->
<link href='http://fonts.googleapis.com/css?family=Roboto:400,300,100,500,700,900' rel='stylesheet' type='text/css'>
<!--//fonts-->

</head>
<body>
	<div class="header">
		<div class="header-left header-work">
			<div class="logo">
				<a href="index.php"><img src="../images/logo.png" alt=""></a>
			</div>
			<div class="top-nav">
				<ul >
						<li><a href="index.php" >Dashboard</a></li>
					<li><a href="addcar.php" class="black" > Add Cars</a></li>	
					<li><a href="addcomfort.php" class="black1"> Add Comfort</a></li>
					<li><a href="addcapacity.php" class="black2" > Add Capacity</a></li>
					<li><a href="addperformance.php" class="black3" > Add Performance</a></li>
					<li class="active"><a href="addsafty.php" class="black4" > Add Safety</a></li>
					<li><a href="addothers.php" class="black4" > Add Others</a></li>
				</ul>
			</div>
			<ul class="social-in">
				<li><a href="#"><i> </i></a></li>
				<li><a href="#"><i class="gmail"> </i></a></li>
				<li><a href="#"><i class="twitter"> </i></a></li>
				<li><a href="#"><i class="pin"> </i></a></li>
				<li><a href="#"><i class="dribble"> </i></a></li>
				<li><a href="#"><i class="behance"> </i></a></li>
			</ul>
			<p class="footer-class">Copyright © 2016 Carworld by  <a href="#" target="_blank">Imili</a> </p>
		</div>
		<!---->
		<div class="header-top">
			<div class="logo-in">
				<a href="index.php"><img src="../images/logo.png" alt=""></a>
			</div>
			<div class="top-nav-in">
			<span class="menu"><img src="../images/menu.png" alt=""> </span>
				<ul >
					<li><a href="index.php" >Dashboard</a></li>
					<li><a href="addcar.php" class="black" > Add Cars</a></li>	
					<li><a href="addcomfort.php" class="black1"> Add Comfort</a></li>
					<li><a href="addcapacity.php" class="black2" > Add Capacity</a></li>
					<li><a href="addperformance.php" class="black3" > Add Performance</a></li>
					<li class="active"><a href="addsafty.php" class="black4" > Add Safety</a></li>
					<li><a href="addothers.php" class="black4" > Add Others</a></li>
				</ul>
				<script>
					$("span.menu").click(function(){
						$(".top-nav-in ul").slideToggle(500, function(){
						});
					});
			</script>

			</div>
			<div class="clear"> </div>
		</div>
			<!---->
		<div class="content">
			<div class="work">
				    <form role="form" action="addsafty.php" method="post">
				<div class="top-contact">
			<?php echo $suc; echo $fail; ?>
				<h3 class="bottom-h3">Add Safty</h3>
				<div class="grid-contact">
				<div class="your-top">
					
						<select name="cname">
<option value="">--- Select Car for add safty details ---</option>
 <?php
	
 $result = mysql_query("SELECT * from cars order by carid asc");
        while($row = mysql_fetch_array($result)) { 
            ?>     
<option value="<?php echo $row['cname']; ?>"><?php echo $row['cname']; ?></option>
		<?php } ?>
</select>						
						<div class="clear"> </div>
					</div>
					<div class="your-top">
						
						<input type="text"  name="fbt" placeholder="Front Brake Type">								
						<div class="clear"> </div>
					</div>
					<div class="your-top">
						
						<input type="text" placeholder="Rear Brake Type" name="rbt" >								
						<div class="clear"> </div>
					</div>
					<div class="your-top">
						
						<input type="text" placeholder="Parking Sensors" name="ps" >								
						<div class="clear"> </div>
					</div>
					<div class="your-top">
						
						<input type="text" placeholder="Centrally Mounted Fuel Tank" name="cmft" >								
						<div class="clear"> </div>
					</div>
					<div class="your-top">
						
						<input type="text" placeholder="Child Safety Locks" name="csl" >								
						<div class="clear"> </div>
					</div>
					<div class="your-top">
						
						<input type="text" placeholder="Day & Night Rear View Mirror" name="rvm">								
						<div class="clear"> </div>
					</div>
						
				</div>
				<div class="grid-contact-in">
			
			<div class="your-top">
						
						<input type="text" placeholder="Engine Immobilizer" name="ei">								
						<div class="clear"> </div>
					</div>
					<div class="your-top">
						
						<input type="text" placeholder="Front Impact Beams" name="fib">								
						<div class="clear"> </div>
					</div>
				
							<div class="your-top">
						
						<input type="text" placeholder="Rear Seat Belts" name="rsb">								
						<div class="clear"> </div>
					</div>
					<div class="your-top">
						
						<input type="text" placeholder="Seat Belt Warning" name="sbw">								
						<div class="clear"> </div>
					</div>
						<div class="your-top">
						
						<input type="text" placeholder="Side Impact Beams" name="sib">								
						<div class="clear"> </div>
					</div>
						
				
				
					<input type="submit" name="btnaddsafty" value="ADD SAFTY">
					<div class="your-top">
					
					</div>
				</div>
				<div class="clear"> </div>
			</div>
			</form>
				<div class="clear"> </div>
			</div>
		</div>
		<div class="clear"> </div>
				<p class="footer-class-in">Copyright © 2016 Carworld Template by  <a href="#" target="_blank">Imili</a> </p>

	</div>
</body>
</html>