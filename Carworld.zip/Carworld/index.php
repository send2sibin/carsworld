<?php include("dbconfig.php"); ?>
<!DOCTYPE html>
<html>
<head>
<title>Carworld</title>
<!-- jQuery-->
<script src="js/jquery.min.js"></script>
<!-- Custom Theme files -->
<!--theme-style-->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />	
<!--//theme-style-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Kappe Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--fonts-->
<link href='http://fonts.googleapis.com/css?family=Roboto:400,300,100,500,700,900' rel='stylesheet' type='text/css'>
<!--//fonts-->
<style>
.grid-search-in input[type="submit"]:hover {
    background: #242b2e;
}
.grid-search-in input[type="submit"] {
 
    
    background: #f16826;
    padding: 0.24em 1.0em;
    text-align: center;
    color: #fff;
    border: none;
    outline: none;
    margin: 0 auto;
    -webkit-appearance: none;
    font-weight: 700;
    transition: 0.5s all;
    -webkit-transition: 0.5s all;
    -o-transition: 0.5s all;
    -ms-transition: 0.5s all;
    -moz-transition: 0.5s all;
    cursor: pointer;
	
	padding-right: 35px;
	float: right;
	border: 2px solid #f16826;
}
</style>
<script src="jquery.min.js"></script>
    <script src="typeahead.min.js"></script>
    <script>
    $(document).ready(function(){
    $('input.typeahead').typeahead({
        name: 'typeahead',
        remote:'search.php?key=%QUERY',
        limit : 10
    });
});
    </script>
    <style type="text/css">
.bs-example{
	font-family: sans-serif;
	position: relative;
	margin: 50px;
}
.typeahead, .tt-query, .tt-hint {
	border: 2px solid #f16826;
	
	font-size: 13px;
	height: 5px;
	line-height: 30px;
	outline: medium none;
	padding: 8px 12px;
	    width: 150px;
}
.typeahead {
	background-color: #FFFFFF;
}
.typeahead:focus {
	border: 2px solid #f12626;
}
.tt-query {
	box-shadow: 0 1px 1px rgba(0, 0, 0, 0.075) inset;
}
.tt-hint {
	color: #999999;
}
.tt-dropdown-menu {
	background-color: #FFFFFF;
	border: 1px solid rgba(0, 0, 0, 0.2);
	
	box-shadow: 0 5px 10px rgba(0, 0, 0, 0.2);
	margin-top: 12px;
	padding: 8px 0;
	width: 190px;
}
.tt-suggestion {
	font-size: 15px;
	line-height: 10px;
	padding: 3px 20px;
}
.tt-suggestion.tt-is-under-cursor {
	background-color: #0097CF;
	color: #FFFFFF;
}
.tt-suggestion p {
	margin: 0;
}
</style>
</head>
<body>
	<div class="header">
	<!---->
		<div class="header-left">
			<div class="logo">
				<a href="index.php"><img src="images/logo.png" alt=""></a>
			</div>
			<div class="top-nav">
				<ul ><li><div class="grid-contact"><form action="searchcars.php" method="post"> <input type="text" name="typeahead" class="typeahead tt-query" autocomplete="off" spellcheck="false" placeholder="Car Name..."></div>
			
<div class="grid-search-in">
  <input type="submit" value="Search" name="btnsearch"></div></form></li><br><br>
					<li class="active" ><a href="index.php" >HOME</a></li>	
					<li><a href="about.php" class="black1"> ABOUT</a></li>
					<li><a href="contact.php" class="black4" > CONTACT</a></li>
				</ul>
			</div>
			<ul class="social-in">
				<li><a href="#"><i> </i></a></li>
				<li><a href="#"><i class="gmail"> </i></a></li>
				<li><a href="#"><i class="twitter"> </i></a></li>
				<li><a href="#"><i class="pin"> </i></a></li>
				<li><a href="#"><i class="dribble"> </i></a></li>
				<li><a href="#"><i class="behance"> </i></a></li>
				
			</ul>
						<p class="footer-class">Copyright © 2016 Carworld by  <a href="#" target="_blank">Imili</a> </p>
		</div>
		<!---->
		<!---->
		<div class="header-top">
			<div class="logo-in">
				<a href="index.php"><img src="images/logo.png" alt=""></a>
				<div class="grid-contact"> <input type="text" name="typeahead" class="typeahead tt-query" autocomplete="off" spellcheck="false" placeholder="Car Name..."></div>
			
<div class="grid-search-in">
  <input type="submit" value="Search"></div>
			</div>
			<div class="top-nav-in">
			<span class="menu"><img src="images/menu.png" alt=""> </span>
				<ul >
					<li class="active" ><a href="index.php" >HOME</a></li>	
					<li><a href="about.php" class="black1"> ABOUT</a></li>
					<li><a href="contact.php" class="black4" > CONTACT</a></li>
				</ul>
				<script>
					$("span.menu").click(function(){
						$(".top-nav-in ul").slideToggle(500, function(){
						});
					});
			</script>

			</div>
			<div class="clear"> </div>
		</div>
			<!---->
				<div class="content">
		<?php
						 $stmt = $DB_con->prepare('SELECT carid, cname,carimg,power FROM cars ORDER BY carid DESC');
	$stmt->execute();
	
	if($stmt->rowCount() > 0)
	{
		while($row=$stmt->fetch(PDO::FETCH_ASSOC))
		{
			extract($row);
			?>
			<div class="content-grid">
				  <a href='car_single.php?cname=<?php echo $row['cname']; ?>' class="b-link-stripe b-animate-go  thickbox">
					<img  src="admin/cars/<?php echo $row['carimg'];?>" style="width:269.8px; height:207.17px;" />
						<div class="b-wrapper">
							<h2 class="b-animate b-from-left    b-delay03 ">
								<span><?php echo $row['cname'];?></span>
								<p><?php echo $row['power'];?></p>
								<i> </i>
							</h2>
						</div>
				</a>
			</div>
			 <?php
		}
	}
	else
	{
		?>
		
	<div><?php header("refresh:0;error.php"); ?></div>


                   
        <?php
	}
	
?>
			
			
			
		</div>
		<div class="clear"> </div>
				<p class="footer-class">Copyright © 2016 Carworld by  <a href="#" target="_blank">Imili</a> </p>
	</div>
</body>
</html>