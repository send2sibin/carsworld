-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 12, 2016 at 12:12 PM
-- Server version: 5.5.24-log
-- PHP Version: 5.4.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `santhith_cars`
--

-- --------------------------------------------------------

--
-- Table structure for table `capacity`
--

CREATE TABLE IF NOT EXISTS `capacity` (
  `cname` varchar(30) DEFAULT NULL,
  `l` varchar(30) DEFAULT NULL,
  `w` varchar(30) DEFAULT NULL,
  `h` varchar(30) DEFAULT NULL,
  `gc` varchar(30) DEFAULT NULL,
  `wb` varchar(30) DEFAULT NULL,
  `ft` varchar(30) DEFAULT NULL,
  `rt` varchar(30) DEFAULT NULL,
  `sc` varchar(30) DEFAULT NULL,
  `ts` varchar(30) DEFAULT NULL,
  `tt` varchar(30) DEFAULT NULL,
  `ws` varchar(30) DEFAULT NULL,
  `nod` varchar(30) DEFAULT NULL,
  `cv` varchar(30) DEFAULT NULL,
  `ftc` varchar(30) DEFAULT NULL,
  UNIQUE KEY `cname` (`cname`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `capacity`
--

INSERT INTO `capacity` (`cname`, `l`, `w`, `h`, `gc`, `wb`, `ft`, `rt`, `sc`, `ts`, `tt`, `ws`, `nod`, `cv`, `ftc`) VALUES
('Hyundai EON', '3495mma', '1550mma', '1500mma', '170mma', '2380mma', '1386mma', '1368mma', '5a', '145/80 R12a', 'Tubelessa', '12 Incha', '5a', '215-litresa', '4a');

-- --------------------------------------------------------

--
-- Table structure for table `cars`
--

CREATE TABLE IF NOT EXISTS `cars` (
  `carid` int(13) NOT NULL AUTO_INCREMENT,
  `cname` varchar(50) DEFAULT NULL,
  `cspeed` varchar(20) DEFAULT NULL,
  `cfuel` varchar(30) DEFAULT NULL,
  `engined` varchar(50) DEFAULT NULL,
  `power` varchar(30) DEFAULT NULL,
  `torque` varchar(30) DEFAULT NULL,
  `acceleration` varchar(30) DEFAULT NULL,
  `carimg` varchar(50) DEFAULT NULL,
  `mlgc` varchar(20) DEFAULT NULL,
  `mlgh` varchar(20) DEFAULT NULL,
  `mlgu` varchar(20) DEFAULT NULL,
  `enginetyp` varchar(20) DEFAULT NULL,
  `details` text,
  PRIMARY KEY (`carid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `cars`
--

INSERT INTO `cars` (`carid`, `cname`, `cspeed`, `cfuel`, `engined`, `power`, `torque`, `acceleration`, `carimg`, `mlgc`, `mlgh`, `mlgu`, `enginetyp`, `details`) VALUES
(1, 'Hyundai EON', '137', 'LPG', '814CC', '55.2bhp@5500rpm', '74.5Nm@4000rpm', '19S', '229073.jpg', '17', '21.1', 'km/kg', 'Bifuel Engine', 'hehegg'),
(2, 'Maruti Alto 800', '140', 'CNG', '796CC', '47.3bhp@6000rpm', '69Nm@3500rpm', '19S', 'Untitled-1.jpg', '29.55', '33.44', 'km/kg', 'F8D Engine', 'r3frfedededed');

-- --------------------------------------------------------

--
-- Table structure for table `comfort`
--

CREATE TABLE IF NOT EXISTS `comfort` (
  `cname` varchar(50) DEFAULT NULL,
  `trantyp` varchar(20) DEFAULT NULL,
  `fs` varchar(30) DEFAULT NULL,
  `rs` varchar(30) DEFAULT NULL,
  `sat` varchar(30) DEFAULT NULL,
  `apo` varchar(30) DEFAULT NULL,
  `chf` varchar(30) DEFAULT NULL,
  `lfwl` varchar(30) DEFAULT NULL,
  `ps` varchar(30) DEFAULT NULL,
  `rsh` varchar(30) DEFAULT NULL,
  `rflo` varchar(30) DEFAULT NULL,
  `rto` varchar(30) DEFAULT NULL,
  `bh` varchar(30) DEFAULT NULL,
  `frs` varchar(30) DEFAULT NULL,
  `ac` varchar(30) DEFAULT NULL,
  `fu` varchar(30) DEFAULT NULL,
  `ast` varchar(30) DEFAULT NULL,
  UNIQUE KEY `cname` (`cname`),
  UNIQUE KEY `cname_2` (`cname`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comfort`
--

INSERT INTO `comfort` (`cname`, `trantyp`, `fs`, `rs`, `sat`, `apo`, `chf`, `lfwl`, `ps`, `rsh`, `rflo`, `rto`, `bh`, `frs`, `ac`, `fu`, `ast`) VALUES
('Hyundai EON', 'Manuall', 'MacPherson Strutt', 'Torsion Beamm', 'Gas Typee', 'YESs', 'YESs', 'YESs', 'YESs', 'YESs', 'YESs', 'YESs', 'Front Doorr', 'Bench Foldingg', 'YESs', 'YESs', 'YES');

-- --------------------------------------------------------

--
-- Table structure for table `others`
--

CREATE TABLE IF NOT EXISTS `others` (
  `cname` varchar(30) DEFAULT NULL,
  `st` varchar(30) DEFAULT NULL,
  `enc` varchar(30) DEFAULT NULL,
  `pwf` varchar(30) DEFAULT NULL,
  `ah` varchar(30) DEFAULT NULL,
  `ervm` varchar(30) DEFAULT NULL,
  `tg` varchar(30) DEFAULT NULL,
  `rs` varchar(30) DEFAULT NULL,
  `cg` varchar(30) DEFAULT NULL,
  `htr` varchar(30) DEFAULT NULL,
  `do` varchar(30) DEFAULT NULL,
  `emt` varchar(30) DEFAULT NULL,
  `eas` varchar(30) DEFAULT NULL,
  `atd` varchar(30) DEFAULT NULL,
  UNIQUE KEY `cname` (`cname`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `others`
--

INSERT INTO `others` (`cname`, `st`, `enc`, `pwf`, `ah`, `ervm`, `tg`, `rs`, `cg`, `htr`, `do`, `emt`, `eas`, `atd`) VALUES
('Hyundai EON', 'Powera', 'BS IVa', 'YESa', 'YESa', 'YESa', 'YESaa', 'YESa', 'YESa', 'YESa', 'YESa', 'YESa', 'NILa', 'YESa');

-- --------------------------------------------------------

--
-- Table structure for table `performance`
--

CREATE TABLE IF NOT EXISTS `performance` (
  `cname` varchar(30) DEFAULT NULL,
  `gb` varchar(30) DEFAULT NULL,
  `dt` varchar(30) DEFAULT NULL,
  `tr` varchar(30) DEFAULT NULL,
  `noc` varchar(30) DEFAULT NULL,
  `vpc` varchar(30) DEFAULT NULL,
  `ed` varchar(50) DEFAULT NULL,
  `vc` varchar(30) DEFAULT NULL,
  `fss` varchar(30) DEFAULT NULL,
  `turboc` varchar(30) DEFAULT NULL,
  `superc` varchar(30) DEFAULT NULL,
  UNIQUE KEY `cname` (`cname`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `performance`
--

INSERT INTO `performance` (`cname`, `gb`, `dt`, `tr`, `noc`, `vpc`, `ed`, `vc`, `fss`, `turboc`, `superc`) VALUES
('Hyundai EON', '5 Speeda', 'FWDa', '4.6 metresa', '3a', '3a', '0.8-litre 55.2bhp 9V Bifuel Ena', 'SOHCa', 'MPFI+LPGa', 'NOa', 'NOa');

-- --------------------------------------------------------

--
-- Table structure for table `safty`
--

CREATE TABLE IF NOT EXISTS `safty` (
  `cname` varchar(30) DEFAULT NULL,
  `fbt` varchar(30) DEFAULT NULL,
  `rbt` varchar(30) DEFAULT NULL,
  `ps` varchar(30) DEFAULT NULL,
  `cmft` varchar(30) DEFAULT NULL,
  `csl` varchar(30) DEFAULT NULL,
  `rvm` varchar(30) DEFAULT NULL,
  `ei` varchar(30) DEFAULT NULL,
  `fib` varchar(30) DEFAULT NULL,
  `rsb` varchar(30) DEFAULT NULL,
  `sbw` varchar(30) DEFAULT NULL,
  `sib` varchar(30) DEFAULT NULL,
  UNIQUE KEY `cname` (`cname`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `safty`
--

INSERT INTO `safty` (`cname`, `fbt`, `rbt`, `ps`, `cmft`, `csl`, `rvm`, `ei`, `fib`, `rsb`, `sbw`, `sib`) VALUES
('Maruti Alto 800', 'Disc', 'YES', 'NIL', 'YES', 'YES', 'YES', 'YES', 'YES', 'YES', 'YES', 'YES'),
('Hyundai EON', 'Discc', 'NILl', 'YESs', 'YESs', 'YESs', 'YESs', 'YESs', 'YESs', 'YESs', 'YESs', 'YESs');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
