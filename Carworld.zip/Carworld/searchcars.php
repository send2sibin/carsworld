<?php include("config.php"); 

if(isset($_POST['btnsearch']))
{
	$cname="";
	$cname=$_POST['typeahead'];

	
	
}

?>
<!DOCTYPE html>
<html>
<head>
<title>Kappe a Personal Portfolio Category Flat Bootstarp Responsive Website Template | Home :: w3layouts</title>
<!-- jQuery-->
<script src="js/jquery.min.js"></script>
<!-- Custom Theme files -->
<!--theme-style-->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />	
<!--//theme-style-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Kappe Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--fonts-->
<link href='http://fonts.googleapis.com/css?family=Roboto:400,300,100,500,700,900' rel='stylesheet' type='text/css'>
<!--//fonts-->
<style>
.grid-search-in input[type="submit"]:hover {
    background: #242b2e;
}
.grid-search-in input[type="submit"] {
 
    /* font-size: 1.1em; */
    background: #1ab5b3;
    padding: 0.24em 1.0em;
    text-align: center;
    color: #fff;
    border: none;
    outline: none;
    margin: 0 auto;
    -webkit-appearance: none;
    font-weight: 700;
    transition: 0.5s all;
    -webkit-transition: 0.5s all;
    -o-transition: 0.5s all;
    -ms-transition: 0.5s all;
    -moz-transition: 0.5s all;
    cursor: pointer;
}
</style>
</head>
<body>
	<div class="header">
	<!---->
		<div class="header-left">
			<div class="logo">
				<a href="index.html"><img src="images/logo.png" alt=""></a>
			</div>
			<div class="top-nav">
				<ul >
					<li  ><a href="index.php" > Dashboard</a></li>
					<li><a href="addcar.php" class="black" > Add Car</a></li>	
					<li  class="active"><a href="carv.php" class="black1"> View Cars</a></li>
					<li><a href="blog.html" class="black2" > BLOG</a></li>
					<li><a href="404.html" class="black3" > SERVICES</a></li>
					<li><a href="contact.html" class="black4" > CONTACT</a></li>
				</ul>
			</div>
			<ul class="social-in">
				<li><a href="#"><i> </i></a></li>
				<li><a href="#"><i class="gmail"> </i></a></li>
				<li><a href="#"><i class="twitter"> </i></a></li>
				<li><a href="#"><i class="pin"> </i></a></li>
				<li><a href="#"><i class="dribble"> </i></a></li>
				<li><a href="#"><i class="behance"> </i></a></li>
				
			</ul>
			<p class="footer-class">Template by  <a href="http://w3layouts.com/" target="_blank">W3layouts</a> </p>
		</div>
		<!---->
		<!---->
		<div class="header-top">
			<div class="logo-in">
				<a href="index.html"><img src="images/logo.png" alt=""></a>
			</div>
			<div class="top-nav-in">
			<span class="menu"><img src="images/menu.png" alt=""> </span>
				<ul >
					<li  ><a href="index.php" > Dashboard</a></li>
					<li><a href="addcar.php" class="black" > Add Car</a></li>	
					<li  class="active"><a href="carv.php" class="black1"> View Cars</a></li>
					<li><a href="blog.html" class="black2" > BLOG</a></li>
					<li><a href="404.html" class="black3" > SERVICES</a></li>
					<li><a href="contact.html" class="black4" > CONTACT</a></li>
				</ul>
				<script>
					$("span.menu").click(function(){
						$(".top-nav-in ul").slideToggle(500, function(){
						});
					});
			</script>

			</div>
			<div class="clear"> </div>
		</div>
			<!---->
		<div class="content">
							<?php
	
 $result = mysql_query("select * from cars where cname='$cname'");
        while($row = mysql_fetch_array($result)) { 
            ?> 
			<div class="content-grid">
				  <a href='car_single.php?cname=<?php echo $row['cname']; ?>' class="b-link-stripe b-animate-go  thickbox">
					<img  src="admin/cars/<?php echo $row['carimg'];?>" style="width:269.8px; height:207.17px;" />
						<div class="b-wrapper">
							<h2 class="b-animate b-from-left    b-delay03 ">
								<span><?php echo $row['cname'];?></span>
								<p><?php echo $row['power'];?></p>
								<i> </i>
							</h2>
						</div>
				</a>
			</div>
		<?php } ?>
			
			
			
		</div>
		<div class="clear"> </div>
		<p class="footer-class-in">Copyright © 2015 Kappe Template by  <a href="http://w3layouts.com/" target="_blank">W3layouts</a> </p>
	</div>
</body>
</html>