<?php
    $key=$_GET['key'];
    $array = array();
    $con=mysql_connect("localhost","root","");
    $db=mysql_select_db("carworld",$con);
    $query=mysql_query("select * from cars where cname LIKE '%{$key}%'");
    while($row=mysql_fetch_assoc($query))
    {
      $array[] = $row['cname'];
    }
    echo json_encode($array);
?>
