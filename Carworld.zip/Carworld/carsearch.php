<?php
if(isset($_POST['btnsearch']))
{
	$cname="";
	$cname=$_POST['typeahead'];

	
	
}



?>
<html>
<body>

<?php echo $cname; ?>
</body>
</html>